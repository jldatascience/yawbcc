Soloq = Soloq or {};
Soloq.db = Soloq.db or {};

-- locals for performance
local tostring = tostring;
local towstring = towstring;
local tonumber = tonumber;
local StringSplit = StringSplit;
local string_find = string.find;
local find = find;
local TextLogGetEntry = TextLogGetEntry;
local TextLogGetNumEntries = TextLogGetNumEntries;
local TextLogAddEntry = TextLogAddEntry;
local TextLogSaveLog = TextLogSaveLog;

local playerName;
-- local rankedScenarioID; -- sc id is incuded in /9 spam

local CHAT_PREFIX = "[Soloq]";
local PREFIX_COLOR = {r=50, g=255, b=10};

local overviewWindowName = "SoloqOverviewWindow";

function Soloq.OnInitialize()

	-- run .sorenable before .mmrenable or else updates don't work 
	if not (ZonepopLite or RoR_SoR) then
		Soloq.enableSoR();
	end

	Soloq.enableMmr();

	playerName = Soloq.FixName( GameData.Player.name );
	Soloq.playerName = playerName;

	Soloq.loadSettings(playerName);

    Soloq.createOverwiewWindow();
    -- enforce saved display mode
    Soloq.setVisibility(WindowGetShowing(overviewWindowName));
    
    if Soloq.db[playerName].firstLoad == true then
        Soloq.setDefaultScale();
        Soloq.db[playerName].firstLoad = false;
    end
	
	LayoutEditor.RegisterWindow ("SoloqOverviewWindow", L"Soloq", L"Soloq", false, false, true, nil);

	CHAT_PREFIX = Soloq.ToRgbWstring( PREFIX_COLOR, "[Soloq]" );
	previousZone = GameData.Player.zone;

	RegisterEventHandler( SystemData.Events.SCENARIO_POST_MODE, "Soloq.ProcessScenarioEnd" );
	RegisterEventHandler( TextLogGetUpdateEventId("Chat"), "Soloq.OnChatLogUpdated" );

	RegisterEventHandler( SystemData.Events.LOADING_END, "Soloq.onLoadingEnd" );

	if LibSlash then
		LibSlash.RegisterSlashCmd("soloq", function(args) Soloq.SlashCmd(args) end);
		Soloq.Print( CHAT_PREFIX .. L" Addon initialized. Use /soloq to toggle." );
	else
		Soloq.Print( CHAT_PREFIX .. L" Addon initialized. Use '/script Soloq.toggleOverviewWindow()' macro to toggle." );
	end
	
end

function Soloq.enableMmr()
	SendChatText(L".mmrenable", ChatSettings.Channels[0].serverCmd);
end

function Soloq.requestQueueStatusUpdate()
	SendChatText(L".uiscstatus", ChatSettings.Channels[0].serverCmd);
end

function Soloq.enableSoR()
    if (tonumber(GameData.Player.level) < 16) then
    	SendChatText(L".sorenable T1", ChatSettings.Channels[0].serverCmd);
    else 
        SendChatText(L".sorenable T4 Forts", ChatSettings.Channels[0].serverCmd);
    end	
end

function Soloq.alternateDisplayModes()
    if Soloq.db[playerName].displayMode == nil or Soloq.db[playerName].displayMode == 2 then
        Soloq.db[playerName].displayMode = 1;
    elseif Soloq.db[playerName].displayMode == 1 then
        Soloq.db[playerName].displayMode = 2;
    end
    Soloq.setVisibility(WindowGetShowing(overviewWindowName));
    Soloq.requestQueueStatusUpdate();
end

function Soloq.clearMmrCache()
	Soloq.db[playerName].soloMmrCache = 0;
    Soloq.db[playerName].premadeMmrCache = 0;
    Soloq.updateMmrLabels();
end

local TIME_DELAY = 3;
local timeLeft = TIME_DELAY;
function Soloq.OnUpdate(elapsed)
	timeLeft = timeLeft - elapsed;
    if (timeLeft > 0) then return end
	Soloq.requestQueueStatusUpdate();
	Soloq.updateMmr();
	Soloq.updateMmrLabels();
	timeLeft = TIME_DELAY;
end


function Soloq.ProcessScenarioEnd()
	if ( (GameData.ScenarioData.mode == GameData.ScenarioMode.POST_MODE) and not GameData.Player.isInSiege ) then
        Soloq.CountScenarioEnding();
	end
end

function Soloq.CountScenarioEnding()
	--d("Soloq.CountScenarioEnding()");
	-- check if we played ranked solo
    local scenarioName = GetScenarioName(GameData.ScenarioData.id);
    --d(scenarioName)     
    if not ( scenarioName:find(L"Ranked Solo") or scenarioName:find(L"Solo Ranked") ) then
         --d("irrelevant sc")
         return
    end

	-- Check which faction won
	local victorRealm;
	if (GameData.ScenarioData.orderPoints > GameData.ScenarioData.destructionPoints) then
		--d("order won");
		victorRealm = GameData.Realm.ORDER;
	elseif (GameData.ScenarioData.orderPoints < GameData.ScenarioData.destructionPoints) then
		--d("des won");
		victorRealm = GameData.Realm.DESTRUCTION;
	else
		--d("draw");
		victorRealm = GameData.Realm.NONE;
	end

	--d("saving total games played")
	Soloq.db[playerName].soloGamesPlayed = Soloq.db[playerName].soloGamesPlayed + 1;

	-- There is a winner
  if (victorRealm ~= GameData.Realm.NONE) then
    if (victorRealm == GameData.Player.realm) then
		--d("saving win game");
        Soloq.db[playerName].soloGamesWon = Soloq.db[playerName].soloGamesWon + 1;
    else
        --d("saving lose game");
        Soloq.db[playerName].soloGamesLost = Soloq.db[playerName].soloGamesLost + 1;
    end
  else
    -- It's a tie
    --d("saving tie game");
    Soloq.db[playerName].soloGamesDrawn = Soloq.db[playerName].soloGamesDrawn + 1;
  end	

	Soloq.updateMatchHistoryLabels();
	Soloq.updateWinrateLabel();

end


function Soloq.OnChatLogUpdated(updateType, filterType)
	
	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end
	if (filterType ~= SystemData.ChatLogFilters.CHANNEL_9) then return end

	local _, _, text = TextLogGetEntry( "Chat", TextLogGetNumEntries("Chat") - 1 );
	text = tostring(text);

	if string_find(text, "SCPlayers:") then
		Soloq.processQueueUpdate(text);
		soloqUpdateCache = text;
	end
	
end

-- hide overview window when entering a scenario and then restore previous visibility after leaving it
local showOverviewWindowOnNextZone;
function Soloq.onLoadingEnd()
	if (GameData.Player.isInScenario == true) then
		Soloq.onEnterRankedScenario();
	else
		Soloq.onEnterRegularZone();
	end
end

function Soloq.onEnterRankedScenario()
	showOverviewWindowOnNextZone = WindowGetShowing("SoloqOverviewWindow");
	Soloq.hideOverviewWindow();
end

function Soloq.onEnterRegularZone()
	if showOverviewWindowOnNextZone and (showOverviewWindowOnNextZone == true) then
		Soloq.showOverviewWindow();
		showOverviewWindowOnNextZone = nil;
	end
end


function Soloq.processQueueUpdate(text)

	-- SCPlayers:ScenarioId:OrderTankCount:OrderDPSCount:OrderHealerCount:DestroTankCount:DestroDPSCount:DestroHealerCount:activeGames
	local data = StringSplit(tostring(text), ":");
	-- rankedScenarioID = tonumber(data[2]);

	local orderTanks = data[3];
	local orderDPS = data[4];
	local orderHealers = data[5];

	local destroTanks = data[6];
	local destroDPS = data[7];
	local destroHealers = data[8];

	local activeGames = tonumber(data[9]);
	local orderQueued = tonumber(orderTanks) + tonumber(orderDPS) + tonumber(orderHealers);
	local destroQueued = tonumber(destroTanks) + tonumber(destroDPS) + tonumber(destroHealers);

	Soloq.updateHeaderLabels(activeGames, orderQueued, destroQueued);
	Soloq.updateQueueLabels(orderTanks, orderDPS, orderHealers, destroTanks, destroDPS, destroHealers, activeGames);

end



function Soloq.updateMmr()

	local newSoloMmr = tonumber(LabelGetText("TomeWindowTitlePageStatSoloMMRNumber"));
	local newPremadeMmr = tonumber(LabelGetText("TomeWindowTitlePageStatPremadeMMRNumber"));

	-- tome of knowledge is being difficult
	if (newSoloMmr == 0) then return end

	-- only cache mmr if there has been an update
	if (newSoloMmr ~= Soloq.db[playerName].soloMmr) then
		Soloq.db[playerName].soloMmrCache = Soloq.db[playerName].soloMmr;
		Soloq.db[playerName].soloMmr = newSoloMmr;
  end
  
	if (newPremadeMmr ~= Soloq.db[playerName].premadeMmr) then
		Soloq.db[playerName].premadeMmrCache = Soloq.db[playerName].premadeMmr;
		Soloq.db[playerName].premadeMmr = newPremadeMmr;
	end

end

function Soloq.loadSettings(playerName)

	Soloq.db[playerName] = Soloq.db[playerName] or {};

     -- 1: full, 2: mini
    Soloq.db[playerName].displayMode = Soloq.db[playerName].displayMode or 1;
    
	Soloq.db[playerName].soloMmr = Soloq.db[playerName].soloMmr or 0;
	Soloq.db[playerName].premadeMmr = Soloq.db[playerName].premadeMmr or 0;
	Soloq.db[playerName].soloMmrCache = Soloq.db[playerName].soloMmrCache or 0;
	Soloq.db[playerName].premadeMmrCache = Soloq.db[playerName].premadeMmrCache or 0;

	Soloq.db[playerName].soloGamesPlayed = Soloq.db[playerName].soloGamesPlayed or 0;
	Soloq.db[playerName].soloGamesWon = Soloq.db[playerName].soloGamesWon or 0;
	Soloq.db[playerName].soloGamesLost = Soloq.db[playerName].soloGamesLost or 0;
    Soloq.db[playerName].soloGamesDrawn = Soloq.db[playerName].soloGamesDrawn or 0;

    if Soloq.db[playerName].firstLoad == nil then
        Soloq.db[playerName].firstLoad = true;
    end

end



function Soloq.SlashCmd(args)

	local command;
	local parameter;
	local separator = string.find(args," ");
	
	if separator then
		command = string.sub(args, 0, separator - 1);
		parameter = string.sub(args, separator + 1, -1);
	else
		command = args;
	end
	
	if command == "" then Soloq.toggleOverviewWindow();
    elseif command == "clearcache" then Soloq.clearMmrCache();
	else Soloq.Print( CHAT_PREFIX .. L" Unknown command." );
	end
	
end