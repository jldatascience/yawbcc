Soloq = Soloq or {};

-- lua locals for performance
local towstring = towstring;
local tonumber = tonumber
local LabelSetText = LabelSetText;
local LabelGetText = LabelGetText;
local math_floor = math.floor

local COLOR_ORDER = {r=0, g=205, b=255};
local COLOR_DESTR = {r=255, g=70, b=70};

local COLOR_NET_GAIN = {r=57, g=255, b=20};
local COLOR_NET_LOSS = {r=255, g=7, b=58};

local playerName;
local overviewWindowName = "SoloqOverviewWindow";

-- added Soloq.db[playerName].displayMode to swap between display modes; 
-- 1: full, 2: mini


function Soloq.createOverwiewWindow()

	playerName = Soloq.playerName;

	if (DoesWindowExist(overviewWindowName) == true) then return end

	CreateWindow(overviewWindowName, false);

	Soloq.setStaticLabels();
	Soloq.updateMatchHistoryLabels();
	Soloq.updateWinrateLabel();
	Soloq.updateMmrLabels();

end

function Soloq.toggleOverviewWindow()
    Soloq.setVisibility(not WindowGetShowing(overviewWindowName));
end

function Soloq.hideOverviewWindow()
    Soloq.setVisibility(false);
end

function Soloq.showOverviewWindow()
    Soloq.setVisibility(true);
end

function Soloq.setVisibility(visibility)
    
    -- full display mode
    if not Soloq.db[playerName].displayMode or Soloq.db[playerName].displayMode == 1 then
        WindowSetShowing(overviewWindowName .. "Header", visibility);
        WindowSetShowing(overviewWindowName .. "CloseButton", visibility);
        WindowSetShowing(overviewWindowName .. "Underline", visibility);
        WindowSetShowing(overviewWindowName .. "Stats", visibility);
        WindowSetShowing(overviewWindowName .. "QueueStatusLeftBorder", visibility);
        WindowSetShowing(overviewWindowName .. "QueueStatusCloseButton", false);
        
    -- mini display mode
    else
        WindowSetShowing(overviewWindowName .. "Header", false);
        WindowSetShowing(overviewWindowName .. "CloseButton", false);
        WindowSetShowing(overviewWindowName .. "Underline", false);
        WindowSetShowing(overviewWindowName .. "Stats", false);
        WindowSetShowing(overviewWindowName .. "QueueStatusLeftBorder", false);
        WindowSetShowing(overviewWindowName .. "QueueStatusCloseButton", visibility);
    end

    WindowSetShowing(overviewWindowName .. "QueueStatus", visibility);
    WindowSetShowing(overviewWindowName, visibility);
end


function Soloq.updateMatchHistoryLabels()
	LabelSetText( overviewWindowName .. "StatsPlayerRecordedValue", towstring(Soloq.db[playerName].soloGamesPlayed));
	LabelSetText( overviewWindowName .. "StatsPlayerGamesWonValue", towstring(Soloq.db[playerName].soloGamesWon));
	LabelSetText( overviewWindowName .. "StatsPlayerGamesLostValue", towstring(Soloq.db[playerName].soloGamesLost));
	LabelSetText( overviewWindowName .. "StatsPlayerGamesDrawnValue", towstring(Soloq.db[playerName].soloGamesDrawn));
end


function Soloq.updateMmrLabels()

	LabelSetText( overviewWindowName .. "StatsPlayerMMRSoloValue", towstring(Soloq.db[playerName].soloMmr) );
	LabelSetText( overviewWindowName .. "StatsPlayerMMRGroupValue", towstring(Soloq.db[playerName].premadeMmr) );

	local function buildNetString(oldValue, newValue)
		local net = newValue - oldValue;
		if ( (oldValue == 0) or (net == 0) ) then return L"~" end
		if (net > 0) then
			return Soloq.ToRgbWstring( COLOR_NET_GAIN, L"+"..towstring(net) );
		else
			return Soloq.ToRgbWstring( COLOR_NET_LOSS, towstring(net) );
		end
	end
	
	LabelSetText( overviewWindowName .. "StatsPlayerMMRSoloNet", buildNetString(Soloq.db[playerName].soloMmrCache, Soloq.db[playerName].soloMmr));
	LabelSetText( overviewWindowName .. "StatsPlayerMMRGroupNet", buildNetString(Soloq.db[playerName].premadeMmrCache, Soloq.db[playerName].premadeMmr));

end

function Soloq.setStaticLabels()

	-- player stats labels
	LabelSetText( overviewWindowName .. "StatsPlayerName", Soloq.FixName( GameData.Player.name ));
	LabelSetText( overviewWindowName .. "StatsPlayerMMR", L"MMR");
	LabelSetText( overviewWindowName .. "StatsPlayerMMRSoloText", L"Solo");
	LabelSetText( overviewWindowName .. "StatsPlayerMMRGroupText", L"Group");
	LabelSetText( overviewWindowName .. "StatsPlayerRecordedText", L"Recorded");
	LabelSetText( overviewWindowName .. "StatsPlayerGamesWonText", L"Wins");
	LabelSetText( overviewWindowName .. "StatsPlayerGamesLostText", L"Losses");
	LabelSetText( overviewWindowName .. "StatsPlayerGamesDrawnText", L"Draws");

	-- queue status labels
	LabelSetText( overviewWindowName .. "QueueStatusTankText", L"TANK");
	LabelSetText( overviewWindowName .. "QueueStatusDpsText", L"DPS");
	LabelSetText( overviewWindowName .. "QueueStatusHealText", L"HEAL");

end


function Soloq.updateWinrateLabel()

	local winrate;
	local gamesPlayed = Soloq.db[playerName].soloGamesLost + Soloq.db[playerName].soloGamesWon;

	if (gamesPlayed == 0) then
		winrate = 0;
	else
		winrate = math_floor( 100 * (Soloq.db[playerName].soloGamesWon / gamesPlayed ) );
	end

	LabelSetText( overviewWindowName .. "StatsPlayerWinrate", towstring(winrate) .. L"% win rate");

end

function Soloq.updateHeaderLabels(activeGames, orderQueued, destroQueued)

	if (activeGames == 1) then
		LabelSetText( overviewWindowName .. "HeaderActiveGamesLabel", L"1 ongoing game");
	else
		LabelSetText( overviewWindowName .. "HeaderActiveGamesLabel", towstring(activeGames) .. L" ongoing games");
	end

	local total = destroQueued + orderQueued;
	total = towstring(total);

	local order = Soloq.ToRgbWstring( COLOR_ORDER, orderQueued );
	local des = Soloq.ToRgbWstring( COLOR_DESTR, destroQueued );

	LabelSetText( overviewWindowName .. "HeaderQueuedPlayersLabel", total .. L" [ " .. order .. L" / " .. des .. L" ] players in queue");

end


function Soloq.updateQueueLabels(orderTanks, orderDPS, orderHealers, destroTanks, destroDPS, destroHealers, activeGames)

    if not Soloq.db[playerName].displayMode or Soloq.db[playerName].displayMode == 1 then
        LabelSetText( overviewWindowName .. "QueueStatusText", L"Queue Status");
    else
        if (activeGames == 1) then
            LabelSetText( overviewWindowName .. "QueueStatusText", L"1 game");
        else
            LabelSetText( overviewWindowName .. "QueueStatusText", activeGames .. L" games");
        end      
    end

	LabelSetText( overviewWindowName .. "QueueStatusOrderTankValue", towstring(orderTanks));
	LabelSetText( overviewWindowName .. "QueueStatusOrderDpsValue", towstring(orderDPS));
	LabelSetText( overviewWindowName .. "QueueStatusOrderHealValue", towstring(orderHealers));

	LabelSetText( overviewWindowName .. "QueueStatusDestroTankValue", towstring(destroTanks));
	LabelSetText( overviewWindowName .. "QueueStatusDestroDpsValue", towstring(destroDPS));
	LabelSetText( overviewWindowName .. "QueueStatusDestroHealValue", towstring(destroHealers));

end



function Soloq.setDefaultScale()
    WindowSetScale( overviewWindowName, 0.75 );
end


function Soloq.showTooltip()
    Tooltips.CreateTextOnlyTooltip(SystemData.MouseOverWindow.name, nil)
	Tooltips.AnchorTooltip(Tooltips.ANCHOR_WINDOW_LEFT)
	Tooltips.SetTooltipText(1, 1, L"Soloq")
	Tooltips.SetTooltipText(2, 1, L"L-Click")
	Tooltips.SetTooltipText(2, 3, L"change display mode")
	Tooltips.SetTooltipText(3, 1, L"R-Click")
	Tooltips.SetTooltipText(3, 3, L"reset MMR delta")
    Tooltips.Finalize()
end














