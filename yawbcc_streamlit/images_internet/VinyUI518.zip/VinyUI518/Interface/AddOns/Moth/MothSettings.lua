
MothSettings = { }

MothSettings =
{

	Version		= 1.3,			-- | Internal									->	Do Not Edit
	Profile		= "Astika",		-- | String: "Default", "Warhammer", "tronned"		See MothProfiles.lua

}