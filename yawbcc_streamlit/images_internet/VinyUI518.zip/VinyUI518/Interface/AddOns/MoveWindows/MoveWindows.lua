MoveWindows = MoveWindows or {};


function MoveWindows.OnInitialize()
	--RegisterEventHandler( SystemData.Events.ENTER_WORLD, "MoveWindows.fixWindows")
	RegisterEventHandler( SystemData.Events.INTERFACE_RELOADED, "MoveWindows.fixWindows" )
	RegisterEventHandler(SystemData.Events.ALL_MODULES_INITIALIZED, "MoveWindows.fixWindows")
end

function MoveWindows.fixWindows()

	-- /script WindowSetMovable("AdvancedRenownTrainingWindow",true)
	if (DoesWindowExist("AdvancedRenownTrainingWindow") == true) then
		WindowSetMovable("AdvancedRenownTrainingWindow", true);
	end	
	
	-- /script WindowSetMovable("EA_Window_InteractionSpecialtyTraining",true)
	if (DoesWindowExist("EA_Window_InteractionSpecialtyTraining") == true) then
		WindowSetMovable("EA_Window_InteractionSpecialtyTraining", true);
	end

	-- /script WindowSetMovable("EA_Window_InteractionSpecialtyTraining",true)
	WindowSetMovable("EA_Window_Backpack", true);

	-- /script WindowSetMovable("BankWindow", true)
	if (DoesWindowExist("BankWindow") == true) then
		WindowSetMovable("BankWindow", true);
		--WindowSetShowing("GuildVaultWindowBuyNewRowButton",false)
		WindowSetShowing("GuildVaultWindowBuyNewRowButton", false);
		--WindowSetAlpha("GuildVaultWindowBuyNewRowButton",0)
		--WindowSetTextAlpha("GuildVaultWindowBuyNewRowButton",0)
	end
	
	-- /script WindowSetMovable("CharacterWindow", true)
	if (DoesWindowExist("CharacterWindow") == true) then
		WindowSetMovable("CharacterWindow", true);
	end
	
	if (DoesWindowExist("EA_StanceBar") == true) then
		WindowSetMovable("EA_StanceBar", true);
	end
	
	--[[
	if (DoesWindowExist("EA_CareerResourceWindow") == true) then
		WindowSetMovable("EA_CareerResourceWindow", true);
	end	
	]]--

	if (DoesWindowExist("GroupWindow") == true) then
		WindowSetShowing("GroupWindow", false);
	end
	
	if (DoesWindowExist("PlayerWindow") == true) then
		WindowSetMovable("PlayerWindow", true);
	end	

	if (DoesWindowExist("ScenarioJoinPromptBox") == true) then
		WindowSetMovable("ScenarioJoinPromptBox", true);
		--WindowSetMovable("EA_SenarioJoinPromptBox", true);
		--WindowSetMovable("EA_SenarioJoinPrompt", true);
	end	

end