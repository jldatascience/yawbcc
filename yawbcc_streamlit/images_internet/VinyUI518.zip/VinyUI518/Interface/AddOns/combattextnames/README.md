# CombatTextNames

Large bold font and ability names for combat text.

Configuration is in the `.lua` (at least for now). You can configure:

- text scale
- text color
- hide ability names on miss text (disrupt/parry etc.)

In `.xml` you can configure:

- text font

## Screenshots

![Screenshot](https://i.imgur.com/pP0XYnQ.png)

(Other addons in the screenshot: TargetInfoRing, BuffHead.)
