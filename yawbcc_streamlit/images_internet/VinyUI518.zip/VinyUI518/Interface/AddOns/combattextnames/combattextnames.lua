-- The MIT License (MIT)
--
-- Copyright (c) 2019 cupnoodles
--
-- Permission is hereby granted, free of charge, to any person obtaining a copy
-- of this software and associated documentation files (the "Software"), to deal
-- in the Software without restriction, including without limitation the rights
-- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
-- copies of the Software, and to permit persons to whom the Software is
-- furnished to do so, subject to the following conditions:
--
-- The above copyright notice and this permission notice shall be included in
-- all copies or substantial portions of the Software.
--
-- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
-- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
-- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
-- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
-- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
-- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
-- SOFTWARE.
--
--
CombatTextNames = {}

local type = type
local towstring = towstring
local GetStringFromTable = GetStringFromTable
local LabelSetText = LabelSetText
local LabelSetFont = LabelSetFont
local GetAbilityData = GetAbilityData
local CreateWindowFromTemplate = CreateWindowFromTemplate

CombatTextNames.Settings = {}
CombatTextNames.Settings.Colors = {
	["COLOR_INCOMING_DAMAGE"] = {r = 255, g = 0, b = 0},
	["COLOR_OUTGOING_DAMAGE"] = {r = 235, g = 235, b = 235},
	
	["COLOR_INCOMING_SPECIAL_DAMAGE"] = {r = 255, g = 66, b = 0},
	["COLOR_OUTGOING_SPECIAL_DAMAGE"] = {r = 235, g = 215, b = 135},
	
	["COLOR_INCOMING_ABSORB"] = {r = 117, g = 146, b = 82},
	["COLOR_OUTGOING_ABSORB"] = {r = 117, g = 146, b = 82},
	
	["COLOR_INCOMING_HEALING"] = {r = 0, g = 200, b = 0},
	["COLOR_OUTGOING_HEALING"] = {r = 0, g = 138, b = 0},
	
	["COLOR_INCOMING_MISS"] = {r = 230, g = 0, b = 38},
	["COLOR_OUTGOING_MISS"] = {r = 230, g = 0, b = 38},
	
	["COLOR_EXPERIENCE_GAIN"] = {r = 255, g = 170, b = 0},
	["COLOR_RENOWN_GAIN"] = {r = 194, g = 56, b = 153},
	["COLOR_INFLUENCE_GAIN"] = {r = 0, g = 170, b = 163}
}
CombatTextNames.Settings.PointGainScaleFactor = 1
CombatTextNames.Settings.OwnEventScaleFactor = 1.1
CombatTextNames.Settings.CriticalScaleFactor = 1.2
CombatTextNames.Settings.EnableNamesOnMissText = false

--[[ ]]--
CombatTextNames.Settings.DefaultPointGainEventAnimationParameters = {
	start = {x = -190, y = -115},
	target = {x = -200, y = -235},
	current = {x = -220, y = -95},
	maximumDisplayTime = 5,
	fadeDelay = 4,
	fadeDuration = 1
}


CombatTextNames.Settings.DefaultHostileEventAnimationParameters =
{
	start = {x = -100, y = -100},
	target = {x = -100, y = -180},
	current = {x = -100, y = -100},
	maximumDisplayTime = 5,
	fadeDelay = 3,
	fadeDuration = 1
}
CombatTextNames.Settings.DefaultFriendlyEventAnimationParameters =
{
	start = {x = 200, y = -420},
	target = {x = 200, y = -100},
	current = {x = 100, y = 70},
	maximumDisplayTime = 5,
	fadeDelay = 4,
	fadeDuration = 1
}

-- Use these macros if you want to toggle text for all/some events:
-- /script CombatTextNames.Toggle(); CombatTextNames.PrintState()
-- /script CombatTextNames.ToggleIncomingDamage(); CombatTextNames.PrintState()
-- /script CombatTextNames.ToggleIncomingHeals(); CombatTextNames.PrintState()
-- /script CombatTextNames.ToggleIncomingMisses(); CombatTextNames.PrintState()
local COLORS = CombatTextNames.Settings.Colors
local POINT_GAIN_SCALE_FACTOR = CombatTextNames.Settings.PointGainScaleFactor
local CRITICAL_SCALE_FACTOR = CombatTextNames.Settings.CriticalScaleFactor
local OWN_EVENT_SCALE_FACTOR = CombatTextNames.Settings.OwnEventScaleFactor
local ENABLE_NAMES_ON_MISS_TEXT = CombatTextNames.Settings.EnableNamesOnMissText
local COMBAT_TEXT_ENABLED = true
local INCOMING_HEALS_ENABLED = false
local INCOMING_MISSES_ENABLED = false
local INCOMING_DAMAGE_ENABLED = false
local DEFAULT_POINT_GAIN_EVENT_ANIMATION_PARAMETERS = CombatTextNames.Settings.DefaultPointGainEventAnimationParameters
local DEFAULT_HOSTILE_EVENT_ANIMATION_PARAMETERS = CombatTextNames.Settings.DefaultHostileEventAnimationParameters
local DEFAULT_FRIENDLY_EVENT_ANIMATION_PARAMETERS = CombatTextNames.Settings.DefaultFriendlyEventAnimationParameters

local EA_System_PointGainEntry_SetupText_ORIG

local COMBAT_EVENT = 1
local CombatEventText = {
	[GameData.CombatEvent.HIT] = L"",
	[GameData.CombatEvent.ABILITY_HIT] = L"",
	[GameData.CombatEvent.CRITICAL] = L"",
	[GameData.CombatEvent.ABILITY_CRITICAL] = L"",
	[GameData.CombatEvent.BLOCK] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_BLOCK),
	[GameData.CombatEvent.PARRY] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_PARRY),
	[GameData.CombatEvent.EVADE] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_EVADE),
	[GameData.CombatEvent.DISRUPT] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_DISRUPT),
	[GameData.CombatEvent.ABSORB] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_ABSORB),
	[GameData.CombatEvent.IMMUNE] = GetStringFromTable("CombatEvents",
	StringTables.CombatEvents
	.LABEL_IMMUNE)
}

function CombatTextNames.Initialize()
	EA_System_EventText.AddCombatEventText = CombatTextNames.AddCombatEventText
	EA_System_EventEntry.SetupText = CombatTextNames.SetupText
	EA_System_PointGainEntry_SetupText_ORIG = EA_System_PointGainEntry.SetupText
	EA_System_PointGainEntry.SetupText = CombatTextNames.SetupPointGainText
	EA_System_EventEntry.m_Template = "CombatTextNames_Window_EventTextLabel"
	EA_System_PointGainEntry.m_Template =
	"CombatTextNames_Window_EventTextLabel"
	
	-- positioning
	EA_System_EventTracker_InitializeAnimationData_ORIG =
	EA_System_EventTracker.InitializeAnimationData
	EA_System_EventTracker.InitializeAnimationData =
	CombatTextNames.InitializeAnimationData
end

function CombatTextNames.SetupPointGainText(self, hitTargetObjectNumber,
	pointAmount, pointType)
	EA_System_PointGainEntry_SetupText_ORIG(self, hitTargetObjectNumber,
	pointAmount, pointType)
	self:SetRelativeScale(POINT_GAIN_SCALE_FACTOR)
end

function CombatTextNames.AddCombatEventText(hitTargetObjectNumber, hitAmount,
	textType, abilityID)
	-- skip incoming events if they're toggled off
	if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
		if (((hitAmount < 0) and not INCOMING_DAMAGE_ENABLED) or
		((hitAmount > 0) and not INCOMING_HEALS_ENABLED) or
		((hitAmount == 0) and not INCOMING_MISSES_ENABLED)) then
			return
		end
	end
	
	local eventData = {
		event = COMBAT_EVENT,
		amount = hitAmount,
		type = textType
	}
	if (EA_System_EventText.EventTrackers[hitTargetObjectNumber] == nil) then
		local newTrackerAnchorWindowName =
		"EA_System_EventTextAnchor" .. hitTargetObjectNumber
		CreateWindowFromTemplate(newTrackerAnchorWindowName,
		"EA_Window_EventTextAnchor",
		"EA_Window_EventTextContainer")
		EA_System_EventText.EventTrackers[hitTargetObjectNumber] =
		EA_System_EventTracker:Create(newTrackerAnchorWindowName,
		hitTargetObjectNumber)
	end
	
	-- #region The SetupText function is going to receive only eventData.amount member.
	-- So we replace eventData.amount with a table that contains all the data we need.
	-- That is, we add ability name there.
	local data = GetAbilityData(abilityID)
	eventData.amount = {}
	eventData.amount.hit = hitAmount
	eventData.amount.name = data.name
	eventData.amount.abilityID = abilityID
	eventData.amount.iconNum = data.iconNum
	-- #endregion
	
	EA_System_EventText.EventTrackers[hitTargetObjectNumber]:AddEvent(eventData)
end

function CombatTextNames.SetupText(self, hitTargetObjectNumber, hitAmount,
	textType)

	local text = L""

	--[[ 
	local name = towstring(hitAmount.name)
	if name ~= L"" then
		name = L" (" .. name .. L")"
	end
	]]--
	
	local hitAmount = hitAmount.hit
	
	-- Sign-adjust healing vs. damage
	if ((textType == GameData.CombatEvent.HIT) or
	(textType == GameData.CombatEvent.ABILITY_HIT) or
	(textType == GameData.CombatEvent.CRITICAL) or
	(textType == GameData.CombatEvent.ABILITY_CRITICAL)) then
		if (hitAmount > 0) then
			text = L"+" .. hitAmount
		else
			text = L"" .. hitAmount
		end
	else
		text = CombatEventText[textType]
		if ENABLE_NAMES_ON_MISS_TEXT then text = text end
	end
	
	local scaling = OWN_EVENT_SCALE_FACTOR
	
	-- Denote critical hits
	if ((textType == GameData.CombatEvent.CRITICAL) or
	(textType == GameData.CombatEvent.ABILITY_CRITICAL)) then
		text = text .. L"!"
		scaling = CRITICAL_SCALE_FACTOR
	end
	
	--d(textType)
	--d(text)
	--d("-----------")
	
	local color = CombatTextNames.GetCombatEventColor(hitTargetObjectNumber,
	hitAmount, textType)
	
	self:SetRelativeScale(scaling)
	LabelSetText(self:GetName(), text)
	LabelSetTextColor(self:GetName(), color.r, color.g, color.b)
end


-- positioning
function CombatTextNames.InitializeAnimationData(self, displayType)
	local baseAnimation = DEFAULT_FRIENDLY_EVENT_ANIMATION_PARAMETERS
	
	if (displayType == COMBAT_EVENT) then
		if (self.m_TargetObject == GameData.Player.worldObjNum) then
			baseAnimation = DEFAULT_FRIENDLY_EVENT_ANIMATION_PARAMETERS
		else
			baseAnimation = DEFAULT_HOSTILE_EVENT_ANIMATION_PARAMETERS
		end
	else
		baseAnimation = DEFAULT_POINT_GAIN_EVENT_ANIMATION_PARAMETERS
	end
	
	local animationData = {
		start = {x = baseAnimation.start.x, y = baseAnimation.start.y},
		target = {x = baseAnimation.target.x, y = baseAnimation.target.y},
		current = {x = baseAnimation.start.x, y = baseAnimation.start.y},
		maximumDisplayTime = baseAnimation.maximumDisplayTime,
		fadeDelay = baseAnimation.fadeDelay,
		fadeDuration = baseAnimation.fadeDuration
	}
	
	return animationData
end


-- coloring
function CombatTextNames.GetCombatEventColor(hitTargetObjectNumber, hitAmount,
	textType)
	local color = COLORS.COLOR_INCOMING_DAMAGE
	
	if (hitAmount > 0) then
		if (textType == GameData.CombatEvent.ABSORB) then
			if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
				color = COLORS.COLOR_INCOMING_ABSORB
			else
				color = COLORS.COLOR_OUTGOING_ABSORB
			end
		elseif (textType == GameData.CombatEvent.BLOCK or textType ==
		GameData.CombatEvent.PARRY or textType ==
		GameData.CombatEvent.DISRUPT or textType ==
		GameData.CombatEvent.EVADE or textType ==
		GameData.CombatEvent.IMMUNE) then
			if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
				color = COLORS.COLOR_INCOMING_MISS
			else
				color = COLORS.COLOR_OUTGOING_MISS
			end
		else
			if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
				color = COLORS.COLOR_INCOMING_HEALING
			else
				color = COLORS.COLOR_OUTGOING_HEALING
			end
		end
	elseif (hitAmount < 0) then
		if ((textType == GameData.CombatEvent.HIT) or
		(textType == GameData.CombatEvent.CRITICAL)) then
			if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
				color = COLORS.COLOR_INCOMING_DAMAGE
			else
				color = COLORS.COLOR_OUTGOING_DAMAGE
			end
		elseif ((textType == GameData.CombatEvent.ABILITY_HIT) or
		(textType == GameData.CombatEvent.ABILITY_CRITICAL)) then
			if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
				color = COLORS.COLOR_INCOMING_SPECIAL_DAMAGE
			else
				color = COLORS.COLOR_OUTGOING_SPECIAL_DAMAGE
			end
		end
	else -- the amount of damage equals zero
		if (hitTargetObjectNumber == GameData.Player.worldObjNum) then
			color = COLORS.COLOR_INCOMING_MISS
		else
			color = COLORS.COLOR_OUTGOING_MISS
		end
	end
	
	return color
end

-- interface functions

function CombatTextNames.Print(str)
	TextLogAddEntry("Chat", 0, towstring("CombatTextNames: " .. str))
end

function CombatTextNames.PrintState()
	local stateText
	if (COMBAT_TEXT_ENABLED and INCOMING_MISSES_ENABLED and
	INCOMING_DAMAGE_ENABLED and INCOMING_HEALS_ENABLED) then
		stateText = "All events enabled."
	else
		stateText = "Disabled: ["
		if not INCOMING_MISSES_ENABLED then
			stateText = stateText .. " inc.miss"
		end
		if not INCOMING_DAMAGE_ENABLED then
			stateText = stateText .. " inc.dmg"
		end
		if not INCOMING_HEALS_ENABLED then
			stateText = stateText .. " inc.heal"
		end
		if not COMBAT_TEXT_ENABLED then stateText = stateText .. " ALL" end
		stateText = stateText .. " ]"
	end
	CombatTextNames.Print(stateText)
end

function CombatTextNames.SetEnabled(b)
	if b then
		CombatTextNames.Enable()
	else
		CombatTextNames.Disable()
	end
end

function CombatTextNames.Disable()
	COMBAT_TEXT_ENABLED = false
	UnregisterEventHandler(SystemData.Events.WORLD_OBJ_COMBAT_EVENT,
	"EA_System_EventText.AddCombatEventText")
end

function CombatTextNames.Enable()
	COMBAT_TEXT_ENABLED = true
	RegisterEventHandler(SystemData.Events.WORLD_OBJ_COMBAT_EVENT,
	"EA_System_EventText.AddCombatEventText")
end

function CombatTextNames.Toggle()
	CombatTextNames.SetEnabled(not COMBAT_TEXT_ENABLED)
end

function CombatTextNames.IsEnabled() return COMBAT_TEXT_ENABLED end

function CombatTextNames.GetState()
	return INCOMING_DAMAGE_ENABLED, INCOMING_HEALS_ENABLED,
	INCOMING_MISSES_ENABLED
end

function CombatTextNames.SetIncomingDamage(b) INCOMING_DAMAGE_ENABLED = b end

function CombatTextNames.SetIncomingHeals(b) INCOMING_HEALS_ENABLED = b end

function CombatTextNames.SetIncomingMisses(b) INCOMING_MISSES_ENABLED = b end

function CombatTextNames.ToggleIncomingDamage()
	INCOMING_DAMAGE_ENABLED = not INCOMING_DAMAGE_ENABLED
end

function CombatTextNames.ToggleIncomingHeals()
	INCOMING_HEALS_ENABLED = not INCOMING_HEALS_ENABLED
end

function CombatTextNames.ToggleIncomingMisses()
	INCOMING_MISSES_ENABLED = not INCOMING_MISSES_ENABLED
end