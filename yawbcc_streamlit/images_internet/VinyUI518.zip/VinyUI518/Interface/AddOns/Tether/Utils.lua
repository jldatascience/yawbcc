Tether = Tether or {};
Tether.Utils = Tether.Utils or {};

-- locals for performance
local sub = sub;
local find = find;
local pairs = pairs;
local towstring = towstring;
local CreateHyperLink = CreateHyperLink;

-- constants
Tether.Utils.DISTANCE_FIX_COEFFICIENT = 1 / 1.06;

Tether.Utils.GUARD_EFFECTS = {};
Tether.Utils.GUARD_EFFECTS[1363] = L"ib";
Tether.Utils.GUARD_EFFECTS[8013] = L"kotbs";
Tether.Utils.GUARD_EFFECTS[9008] = L"sm";
Tether.Utils.GUARD_EFFECTS[1674] = L"bo";
Tether.Utils.GUARD_EFFECTS[8325] = L"chosen";
Tether.Utils.GUARD_EFFECTS[9325] = L"bg";

Tether.Utils.TANK_CLASS_IDS = {};
Tether.Utils.TANK_CLASS_IDS[24] = true; 	-- bo
Tether.Utils.TANK_CLASS_IDS[64] = true; 	-- chosen
Tether.Utils.TANK_CLASS_IDS[104] = true; 	-- bg
Tether.Utils.TANK_CLASS_IDS[20] = true; 	-- ib
Tether.Utils.TANK_CLASS_IDS[61] = true; 	-- kotbs
Tether.Utils.TANK_CLASS_IDS[100] = true; 	-- sm

Tether.Utils.TURRET_CLASS_IDS = {};
Tether.Utils.TURRET_CLASS_IDS[67] = true; 	-- magus
Tether.Utils.TURRET_CLASS_IDS[23] = true; 	-- engi

Tether.Utils.COLOR_CHAT_PREFIX = {R=50,G=255,B=10};
Tether.Utils.COLOR_DEFAULT = {R=160,G=160,B=160};
Tether.Utils.COLOR_GREEN = {R=50,G=255,B=50};
Tether.Utils.COLOR_RED = {R=255,G=50,B=50};


function Tether.Utils.isTableEmpty(t)
	if not t then return nil end
    for _,_ in pairs(t) do
		return false;
    end
    return true;
end

function Tether.Utils.Print(str)
    EA_ChatWindow.Print(towstring(str));
end

function Tether.Utils.toRgbWstring(color, str)
	return towstring(CreateHyperLink(L"", towstring(str), {color.R, color.G, color.B}, {}));
end

function Tether.Utils.isGroupMemberDead(playerName)
    if not LibGroup or not playerName or not LibGroup.GroupMembers.ByName[playerName] then return nil end
    return not LibGroup.GroupMembers.ByName[playerName].IsAlive or nil;
end

function Tether.Utils.fixName(name)
	if not name then return nil end
	local pos = name:find (L"^", 1, true);
	if (pos) then name = name:sub (1, pos - 1); end	
	return name;
end

function Tether.Utils.getColorByGuardDistance(distance)
    if not distance then return Tether.Utils.COLOR_DEFAULT end -- or type(distance) ~= "number"
	if distance <= 30 and distance >= 0 then
		return Tether.Utils.COLOR_GREEN;
	else
		return Tether.Utils.COLOR_RED;
	end
end