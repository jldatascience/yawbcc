Tether = Tether or {};

-- locals for performance
local Print = Tether.Utils.Print;
local fixName = Tether.Utils.fixName;
local toRgbWstring = Tether.Utils.toRgbWstring;

-- syntax sugar
local TANK_CLASS_IDS = Tether.Utils.TANK_CLASS_IDS;
local TURRET_CLASS_IDS = Tether.Utils.TURRET_CLASS_IDS;
local COLOR_CHAT_PREFIX = Tether.Utils.COLOR_CHAT_PREFIX;

-- runtime
Tether.selfId = nil;
Tether.selfName = nil;
Tether.playingTank = nil;
Tether.chatPrefix = "[Tether]";


-- /script Tether.SetOffset(70)
function Tether.SetOffset(value)
	WindowSetOffsetFromParent("TetherTargetWindow", 0, value);
	Tether.SavedSettings.VerticalOffset = value;
end

function Tether.initialize()

    Tether.selfId = GameData.Player.worldObjNum;
    Tether.selfName = fixName(GameData.Player.name);
	Tether.playingTank = TANK_CLASS_IDS[GameData.Player.career.id] or false;
	Tether.playingTurretClass = TURRET_CLASS_IDS[GameData.Player.career.id] or false;
    Tether.chatPrefix = toRgbWstring(COLOR_CHAT_PREFIX, Tether.chatPrefix);

    Tether.loadSettings();
    
    Tether.createConfigWindow();
    Tether.setUpCheckboxes();
	
    if Tether.SavedSettings.guardOutTracker == true then
        Tether.GuardOut.initialize();
    else
        if Tether.SavedSettings.guardInTracker == true then
            Tether.GuardIn.initialize();
        end
        if Tether.SavedSettings.turretTracker == true and Tether.playingTurretClass == true then
            Tether.TurretTracker.initialize();
        end
	end

	RegisterEventHandler( SystemData.Events.LOADING_BEGIN, "Tether.Line.clearForcedTarget" );

    Tether.Line.initialize();

	if LibSlash then
		LibSlash.RegisterSlashCmd("tether", function(args) Tether.SlashCmd(args) end)
		Print(Tether.chatPrefix .. L" Addon initialized. Use /tether to adjust offset or /libgroup to adjust distance refresh rate.");
	else
		Print(Tether.chatPrefix .. L" Addon initialized.");
	end
	
	Tether.Line.clearTarget();

end

function Tether.shutDown()
    UnregisterEventHandler(SystemData.Events.LOADING_BEGIN, "Tether.Line.clearForcedTarget");
end

function Tether.SlashCmd(args)

	local command;
	local parameter;
	local separator = string.find(args," ");
	
	if separator then
		command = string.sub(args, 0, separator-1);
		parameter = string.sub(args, separator+1, -1);
	else
		command = string.sub(args, 0, separator);
	end

    if command == "force" then
        Tether.Line.forceTarget();
    elseif command == "clear" then
        Tether.Line.clearTarget();
    elseif command == "config" or command == "" then
        Tether.showConfig();    
    elseif command == "clog" then
        Tether.toggleCombatLog();
	elseif command == "help" then
		Print(Tether.chatPrefix .. L" Available commands:")
		Print('<LINK data=\"0\" text=\"/tether force\" color=\"255,255,10\"> - Creates a line between you and your friendly target. This disables automatic guard tracking until "/tether clear" command is run.');
		Print("<LINK data=\"0\" text=\"/tether clear\" color=\"255,255,10\"> - Clears tether to your current target and all tanks guarding you.");
		Print("<LINK data=\"0\" text=\"/tether config\" color=\"255,255,10\"> - Opens config window.");
	else
		Print("<LINK data=\"0\" text=\"[Tether]\" color=\"255,50,50\"> Unknown command. Run <LINK data=\"0\" text=\"/tether help\" color=\"255,255,10\"> to see available commands.");
	end
	
end

function Tether.loadSettings()
    Tether.SavedSettings =  Tether.SavedSettings or {};
    Tether.SavedSettings.VerticalOffset = Tether.SavedSettings.VerticalOffset or 140;

    if Tether.SavedSettings.guardOutTracker ~= nil then
        Tether.SavedSettings.guardOutTracker = Tether.SavedSettings.guardOutTracker;
    else
        Tether.SavedSettings.guardOutTracker = TANK_CLASS_IDS[GameData.Player.career.id] or false;
    end

    if Tether.SavedSettings.guardInTracker ~= nil then
        Tether.SavedSettings.guardInTracker = Tether.SavedSettings.guardInTracker;
    else
        Tether.SavedSettings.guardInTracker = (not TANK_CLASS_IDS[GameData.Player.career.id]) or false;
    end

    if Tether.SavedSettings.turretTracker ~= nil then
        Tether.SavedSettings.turretTracker = Tether.SavedSettings.turretTracker;
    else
        Tether.SavedSettings.turretTracker = TURRET_CLASS_IDS[GameData.Player.career.id] or false;
    end

    if Tether.SavedSettings.lineTextureId ~= nil then
        Tether.SavedSettings.lineTextureId = Tether.SavedSettings.lineTextureId;
    else
        Tether.SavedSettings.lineTextureId = 1;
    end

end

function Tether.setDefaultOffset()
	Tether.SavedSettings.VerticalOffset = 140;
end


function Tether.toggleCombatLog()
	local textLogEnabled = TextLogGetEnabled("Combat");
	TextLogSetEnabled("Combat", ( not(textLogEnabled) ));	
	if (textLogEnabled == true) then 
		EA_ChatWindow.Print(L"Combat log is now OFF.")
	else
		EA_ChatWindow.Print(L"Combat log is now ON.")
	end
end


function Tether.isTrackingMyGuard()
    return Tether.GuardOut and Tether.GuardOut.enabled and (Tether.GuardOut.enabled == true) or false;
end

function Tether.isTrackingMyTanks()
    return Tether.GuardIn and Tether.GuardIn.enabled and (Tether.GuardIn.enabled == true) and (Tether.GuardIn.numberOfTanksGuardingMe > 0) or false;
end

function Tether.iAmGuarded()
    return Tether.GuardIn and Tether.GuardIn.numberOfTanksGuardingMe and (Tether.GuardIn.numberOfTanksGuardingMe > 0) or false;
end

function Tether.isTrackingMyTurret()
    return Tether.TurretTracker and Tether.TurretTracker.enabled and (Tether.TurretTracker.enabled == true) and Tether.TurretTracker.turretIsDeployed and (Tether.TurretTracker.turretIsDeployed == true) or false;
end

function Tether.isForcedToTarget()
    return forcedTarget or false;
end





