Tether = Tether or {};
Tether.GuardIn = Tether.GuardIn or {};

-- locals for performance
local pairs = pairs;
local tostring = tostring;
local towstring = towstring;
local StringSplit = StringSplit
local string_find = string.find;
local TextLogGetEntry = TextLogGetEntry;
local TextLogGetNumEntries = TextLogGetNumEntries;
local GetBuffs = GetBuffs;

local isTableEmpty = Tether.Utils.isTableEmpty;
local Print = Tether.Utils.Print
local GUARD_EFFECTS = Tether.Utils.GUARD_EFFECTS;

-- syntax sugar
local this = Tether.GuardIn;

-- runtime
this.enabled = false;
this.tanksGuardingMe = {};
this.numberOfTanksGuardingMe = 0;

local function clearTanksGuardingMe()
    this.tanksGuardingMe = {};
    this.numberOfTanksGuardingMe = 0;
end

function Tether.GuardIn.initialize()
    if not this.enabled or (this.enabled == false) then
        RegisterEventHandler( TextLogGetUpdateEventId("Chat"), "Tether.GuardIn.onChatLogUpdated" );
        this.enabled = true;
        --d("[Tether] GuardIn tracker has been initialized.");
    end    
end

function Tether.GuardIn.shutDown()
    if this.enabled == true then
        clearTanksGuardingMe();
        UnregisterEventHandler( TextLogGetUpdateEventId("Chat"), "Tether.GuardIn.onChatLogUpdated" );
        this.enabled = false;
        --d("[Tether] GuardIn tracker has been disabled.");
    end
end

function Tether.GuardIn.onChatLogUpdated(updateType, filterType)

	if (updateType ~= SystemData.TextLogUpdate.ADDED) then return end
    if (filterType ~= 65) then return end -- only listen to /9

    local _, _, text = TextLogGetEntry("Chat", TextLogGetNumEntries("Chat") - 1);
	text = tostring(text);

    -- only listen for LibGuard updates
    if not string_find(text, "LibGuard") then return end

    -- LibGuard:Apply:Tankname:Myname
    -- LibGuard:Remove:Tankname:Myname
    local data = StringSplit(text, ":");

    -- todo
    -- check if recipient is actually me 
    -- (so far it seems updates are already filtered like so by the server)

    local action = data[2];
    local tankName = towstring(data[3]);

    if action == "Apply" then

        this.tanksGuardingMe[tankName] = true;
        this.numberOfTanksGuardingMe = this.numberOfTanksGuardingMe + 1 or 1;

        -- find out who the closest tank is
        local distance;
		for tName, _ in pairs (this.tanksGuardingMe) do
			if LibGroup.GroupMembers.ByName[tName] then
				local dist = LibGroup.GroupMembers.ByName[tName].Distance;
				if (not distance) or (distance > dist) then
                    distance = dist;
                    Tether.Line.attatchToTarget({
                        objectId = LibGroup.GroupMembers.ByName[tName].WorldObjectId,
                        name = tName
                    });
				end
			end
        end

    elseif action == "Remove" then
        this.tanksGuardingMe[tankName] = nil;
        this.numberOfTanksGuardingMe = this.numberOfTanksGuardingMe - 1;
        -- sanity check
        if this.numberOfTanksGuardingMe < 0 then this.numberOfTanksGuardingMe = 0; end
        -- nobody is guarding me and we are not tracking a turret
        if (this.numberOfTanksGuardingMe == 0) and (Tether.isTrackingMyTurret() == false) then
             Tether.Line.clearTarget();
        end
    end

end