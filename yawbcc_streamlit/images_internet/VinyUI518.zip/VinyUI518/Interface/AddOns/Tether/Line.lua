-- based on teather by Sullemunk
-- https://tools.idrinth.de/addons/guardpack/

Tether = Tether or {};
Tether.Line = Tether.Line or {};

-- locals for performance
local type = type
local pairs = pairs
local ipairs = ipairs
local towstring = towstring
local tostring = tostring
local math_floor = math.floor
local math_sqrt = math.sqrt 
local math_atan2 = math.atan2
local math_rad = math.rad
local math_cos = math.cos
local math_sin = math.sin
local math_pi = math.pi

local LabelSetText = LabelSetText;
local WindowSetAlpha = WindowSetAlpha;
local WindowClearAnchors = WindowClearAnchors;
local WindowSetTintColor = WindowSetTintColor;
local WindowGetShowing = WindowGetShowing;
local WindowSetShowing = WindowSetShowing;
local WindowGetScreenPosition = WindowGetScreenPosition;
local DynamicImageSetRotation = DynamicImageSetRotation;
local WindowSetOffsetFromParent = WindowSetOffsetFromParent

local Print = Tether.Utils.Print;
local fixName = Tether.Utils.fixName;
local isGroupMemberDead = Tether.Utils.isGroupMemberDead;
local getColorByGuardDistance = Tether.Utils.getColorByGuardDistance;
local toRgbWstring = Tether.Utils.toRgbWstring;


-- syntax sugar
local this = Tether.Line;
this.target = {objectId = nil, name = nil};

local GuardIn; -- object Tether.GuardIn;
local GuardOut; -- object Tether.GuardOut;
local TurretTracker; -- object Tether.TurretTracker;

local trackingMyGuard; -- function Tether.Line.isTrackingMyGuard()
local trackingMyTanks;  -- function Tether.Line.trackingMyTanks()
local trackingMyTurret; -- function Tether.Line.trackingMyTurret()


-- constants
local DEFAULT_ANCHOR_TEXTURE = "icon000080"; -- 80: shield

local DISTANCE_FIX_COEFFICIENT = Tether.Utils.DISTANCE_FIX_COEFFICIENT;
local COLOR_DEFAULT = Tether.Utils.COLOR_DEFAULT;
local COLOR_RED = Tether.Utils.COLOR_RED;

local TEXTURE_NAME_BY_ID = {};
TEXTURE_NAME_BY_ID[1] = "TetherStock";
TEXTURE_NAME_BY_ID[2] = "TetherSlim";
TEXTURE_NAME_BY_ID[3] = "TetherOpaque";

-- runtime
local UIScale;
local ResolutionScale;
local GlobalScale;
local ScreenWidthX,ScreenHeightY;
local MaxLines = 0;
local NumberLines;
local IsTeathered = 0.1;
local LineLength = 58;

local function hideLine()
	for i=1,MaxLines do
		WindowSetAlpha("TetherLine"..i.."Line", 0);
		WindowClearAnchors( "TetherLine"..i);
	end
	WindowSetAlpha( "TetherLineEndLine", 0);
end

local function setTurretInfoDistancelabel(distance)
    LabelSetText("TetherTurretInfoDistanceLabel", L"Turret: " .. toRgbWstring(TurretTracker.distanceColor, distance or "n/a") .. L" ft");
    LabelSetText("TetherTurretInfoDistanceLabelTint", L"Turret: " .. (distance or L"n/a") .. L" ft");
end

local isTurretInfoVisible;
-- this needs a throttle because it's called on every frame update
local function setTurretInfoWindowVisibility(newVisibility)
    if newVisibility ~= isTurretInfoVisible then
        WindowSetShowing( "TetherTurretInfo", newVisibility);
        isTurretInfoVisible = newVisibility;
    end
end

local function updateInterfaceScale()
	UIScale = InterfaceCore.GetScale();
	ResolutionScale = InterfaceCore.GetResolutionScale();
	GlobalScale = SystemData.Settings.Interface.globalUiScale;
	ScreenWidthX,ScreenHeightY = GetScreenResolution();
	MaxLines = ((((ScreenWidthX+ScreenHeightY/2)/ResolutionScale)/GlobalScale)/LineLength)/2;
end

function Tether.Line.initialize()
    
    --d("Tether.Line.initialize()")

    -- set up syntax sugar
    GuardIn = Tether.GuardIn;
    GuardOut = Tether.GuardOut;
    TurretTracker = Tether.TurretTracker;
    trackingMyGuard = Tether.isTrackingMyGuard;
    trackingMyTanks = Tether.isTrackingMyTanks;
    trackingMyTurret = Tether.isTrackingMyTurret;

    updateInterfaceScale();
    this.createWindows();

    if (DoesWindowExist("TetherTurretInfo") == true) then
        isTurretInfoVisible = WindowGetShowing("TetherTurretInfo");
    else
        isTurretInfoVisible = false;
    end

    WindowSetOffsetFromParent("TetherTargetWindow", 0, Tether.SavedSettings.VerticalOffset);

    this.setAnchorTexture(DEFAULT_ANCHOR_TEXTURE);

    WindowSetShowing("TetherTargetWindow", false);
    WindowSetShowing("TetherSelfWindow", false);
    
end

function Tether.Line.createWindows()

    if (DoesWindowExist("TetherAnchorWindow") == false) then CreateWindow( "TetherAnchorWindow", false); end
	if (DoesWindowExist("TetherTargetWindow") == false) then CreateWindow( "TetherTargetWindow", false); end
	WindowClearAnchors( "TetherTargetWindow");
	if (DoesWindowExist("TetherSelfWindow") == false) then CreateWindow( "TetherSelfWindow", false); end

    if (Tether.TurretTracker.enabled == true) and (DoesWindowExist("TetherTurretInfo") == false) then
        CreateWindow( "TetherTurretInfo", true);
        LayoutEditor.RegisterWindow ("TetherTurretInfo", L"TurretInfo", L"TurretInfo", false, false, true, nil);
        WindowSetAlpha("TetherTurretInfo", 0);
    end


    -- create line segments
    for i=1, MaxLines do
        local window = "TetherLine"..i;
        if (DoesWindowExist(window) == false) then
            CreateWindowFromTemplate(window, "LineTemplate", "TetherSelfWindow");
            WindowSetShowing(window.."Line", true);
            WindowSetAlpha(window.."Line", 0);
    	end
    end
    if (DoesWindowExist("TetherLineEnd") == false) then CreateWindowFromTemplate("TetherLineEnd", "LineTemplate", "TetherSelfWindow"); end

    Tether.Line.setLineTexture(Tether.SavedSettings.lineTextureId);

end

function Tether.Line.setAnchorTexture(texture)
    texture = texture or DEFAULT_ANCHOR_TEXTURE;
    CircleImageSetTexture( "TetherTargetWindowIcon", texture, 32, 32);
    CircleImageSetTexture( "TetherSelfWindowIcon", texture, 32, 32);
end


function Tether.Line.clearTarget()
    --d("Tether.Line.clearTarget()")
    --d(this.target)
    hideLine();
	WindowSetShowing("TetherTargetWindow", false);
	WindowSetShowing("TetherSelfWindow", false);
    if this.target and this.target.objectId then
	    DetachWindowFromWorldObject("TetherAnchorWindow", this.target.objectId);
    end
    this.target = {objectId = nil, name = nil};
	forcedTarget = false;
	IsTeathered = 0.2;
end

function Tether.Line.forceTarget()
    --d("Tether.forceTarget()")
	TargetInfo:UpdateFromClient();

    local newObjectId = TargetInfo:UnitEntityId("selffriendlytarget");
	if not newObjectId or (newObjectId == 0) then 
		Print(Tether.chatPrefix .. L" Could not get target ID.");
        this.clearTarget();
		return;
	end
	
	local newName = fixName(TargetInfo:UnitName("selffriendlytarget"));
	if not newName or (newName == L"") or (newName == "") then
        Print(Tether.chatPrefix .. L" Could not get target name.");
        this.clearTarget();
		return;
	end
	
    Tether.Line.setAnchorTexture(DEFAULT_ANCHOR_TEXTURE);

	forcedTarget = true;
	this.attatchToTarget({objectId = newObjectId, name = newName});
end

function Tether.Line.clearForcedTarget()
    if not forcedTarget or forcedTarget == false then return end
    this.clearTarget();
end

function Tether.Line.attatchToTarget(newTarget)
    
    if not newTarget or not newTarget.objectId or not newTarget.name then return end -- new target is invalid
    if this.target.name and newTarget.name == this.target.name and newTarget.objectId == this.target.objectId then  -- new target is the same as old target
        --d("same target")
        return
    end 
    if newTarget.objectId == 0 or newTarget.name == "" or newTarget.name == L"" then return end -- new target has invalid properties
    if newTarget.objectId == GameData.Player.worldObjNum or newTarget.name == Tether.selfName then return end -- new target is self

    --d("Tether.Line.attatchToTarget(newTarget)")
    --d(newTarget)

    -- detatch from old target if it exists
    if this.target and this.target.objectId then
        DetachWindowFromWorldObject("TetherAnchorWindow", this.target.objectId);
    end

    this.target = {objectId = newTarget.objectId, name = newTarget.name};
    IsTeathered = 0.1;
    
    AttachWindowToWorldObject("TetherAnchorWindow", this.target.objectId);

    -- update anchor textures and offset
    if newTarget.isTurret and newTarget.isTurret == true then
        this.setAnchorTexture(TurretTracker.turretTexture);
        LabelSetText("TetherTurretInfoIconLabel", TurretTracker.turretChatIcon or L"<icon00080>");
        if newTarget.isSpecialTurret and newTarget.isSpecialTurret == true then
            WindowSetOffsetFromParent("TetherTargetWindow", 0, Tether.SavedSettings.VerticalOffset + 40);
        end
    else
        WindowSetOffsetFromParent("TetherTargetWindow", 0, Tether.SavedSettings.VerticalOffset);
        this.setAnchorTexture(DEFAULT_ANCHOR_TEXTURE);
    end

	WindowSetShowing("TetherTargetWindow", true);
    WindowSetShowing("TetherSelfWindow", true);
    
end

function Tether.Line.draw(timeElapsed)

	-- sanity check
	if not this.target or not this.target.name then return end
	
    hideLine();
    
    local isDistant;
    local distance;
    local colorByDistance = COLOR_DEFAULT;
    
    -- playing a tank or forced a target with a slash command
    if (trackingMyGuard() == true) or forcedTarget == true then

        --if (forcedTarget == true) then d("target is forced") else d(L"I'm guarding someone"); end

		if LibGroup.GroupMembers.ByName[this.target.name] then
            distance = LibGroup.GroupMembers.ByName[this.target.name].Distance;
            isDistant = LibGroup.GroupMembers.ByName[this.target.name].IsDistant;
            -- occasionally in rvr worldObj numbers are updated to make room for more players 
            if this.target.objectId ~= LibGroup.GroupMembers.ByName[this.target.name].WorldObjectId then
                --d("updating object id")
                this.attatchToTarget({
                    objectId = LibGroup.GroupMembers.ByName[this.target.name].WorldObjectId,
                    name = this.target.name
                });
            end
        end

        -- normalize distance data
        if distance then
            distance = math_floor(distance * DISTANCE_FIX_COEFFICIENT);
        end

    -- playing dps
    elseif (trackingMyTanks() == true) or (trackingMyTurret() == true) then
        --d("im guarded or have a turret")

        -- select closest tank and show turret as text only
        if GuardIn.numberOfTanksGuardingMe > 0 then

            local id;
            local name;
            local alive;
            for tankName, _ in pairs (GuardIn.tanksGuardingMe) do
                --d(L"active tank: "..tankName); -- name keys are wstrings
                if LibGroup.GroupMembers.ByName[tankName] then
                    --d(L"checking distance");
                    local dist = LibGroup.GroupMembers.ByName[tankName].Distance;
                    if (not distance) or (distance > dist) and (not alive or LibGroup.GroupMembers.ByName[tankName].IsAlive == true) then
                        distance = dist;
                        alive = true;
                        isDistant = LibGroup.GroupMembers.ByName[tankName].IsDistant;
                        id = LibGroup.GroupMembers.ByName[tankName].WorldObjectId;
                        name = tankName;
                    end
                end
            end

            this.attatchToTarget({ objectId = id, name = name });

            -- normalize distance data
            if distance then
                distance = math_floor(distance * DISTANCE_FIX_COEFFICIENT);
            end

            -- show turret mini window
            if TurretTracker.turretIsDeployed == true then
                setTurretInfoDistancelabel(TurretTracker.distanceToTurret);
                setTurretInfoWindowVisibility(true); -- this will return if window is already visible
            end

        -- otherwise select turret and draw the line to it
        elseif (TurretTracker.turretIsDeployed == true) then

            --d("switching to pet");
            this.attatchToTarget(TurretTracker.target);
            distance = TurretTracker.distanceToTurret;
            colorByDistance = TurretTracker.distanceColor or COLOR_DEFAULT;
            --hide turret mini window
            setTurretInfoWindowVisibility(false); -- this will return if window is already hidden

        end

    else
        --d("undefined circumstances occured while running Tether.Line.draw()")
        return;
    end

    -- select a color that corresponds to the distance and target being tracked
    local targetIsDead;
    if (trackingMyTanks() == true) or (trackingMyGuard() == true) then 
        targetIsDead = isGroupMemberDead(this.target.name);
        if targetIsDead == true then
            colorByDistance = COLOR_DEFAULT;
        else
            colorByDistance = getColorByGuardDistance(distance) or COLOR_DEFAULT;
        end
    end

	local newLineOpacity = 0;
	if (WindowGetShowing("TetherAnchorWindow") == true) then newLineOpacity = 1; end	
    WindowSetAlpha("TetherTargetWindow", newLineOpacity);

    -- handle all cases where the line does not need to be drawn
    if forcedTarget == false then
        if (not distance) or (isDistant == true) then
            WindowSetAlpha("TetherTargetWindow", 0);
            WindowSetTintColor("TetherSelfWindowCircle", COLOR_DEFAULT.R, COLOR_DEFAULT.G, COLOR_DEFAULT.B);
            LabelSetText("TetherSelfWindowLabel", L"Distant");
            return;
        elseif distance and distance > 130 then
            if targetIsDead == true then
                WindowSetTintColor("TetherSelfWindowCircle", COLOR_DEFAULT.R, COLOR_DEFAULT.G, COLOR_DEFAULT.B);
                LabelSetText("TetherSelfWindowLabel", L"Dead");
            else
                WindowSetTintColor("TetherSelfWindowCircle", colorByDistance.R, colorByDistance.G, colorByDistance.B);
                LabelSetText("TetherSelfWindowLabel", L"Far");
            end
            WindowSetAlpha("TetherTargetWindow", 0);
            return;
        end
    end

    -- handle provided distance data
    if distance then
        if targetIsDead == true then
            WindowSetTintColor("TetherSelfWindowCircle", COLOR_DEFAULT.R, COLOR_DEFAULT.G, COLOR_DEFAULT.B);
            LabelSetText("TetherSelfWindowLabel", L"Dead");
        else
            LabelSetText("TetherSelfWindowLabel",towstring(distance .. L"ft"));
            WindowSetTintColor("TetherSelfWindowCircle", colorByDistance.R, colorByDistance.G, colorByDistance.B);
        end
    else
        LabelSetText("TetherSelfWindowLabel", L"N/A");
        WindowSetTintColor("TetherSelfWindowCircle", COLOR_DEFAULT.R, COLOR_DEFAULT.G, COLOR_DEFAULT.B);
    end

	-- if target anchor is not on screen there is no need to draw a line
	if newLineOpacity == 0 then return end
	
	-- calculate the angle at which  the lines must be aligned in this moment
	local TargetTempWindowX, TargetTempWindowY = WindowGetScreenPosition("TetherTargetWindow");
	local PlayerTempWindowX, PlayerTempWindowY = WindowGetScreenPosition("TetherSelfWindow");
	local xDiff = PlayerTempWindowX - TargetTempWindowX;
	local yDiff = PlayerTempWindowY - TargetTempWindowY;
	local Degrees = (math_atan2(yDiff,xDiff)*(180 / math_pi) - 90);
	local DistX = PlayerTempWindowX - TargetTempWindowX;
	local DistY = PlayerTempWindowY - TargetTempWindowY;
	local radius1 = 20;
	local TestDistance = (math_sqrt(DistX*DistX+DistY*DistY))/UIScale;
    NumberLines = math_floor(TestDistance/LineLength)+1;
	local xDiff2 = PlayerTempWindowX-TargetTempWindowX;
	local yDiff2 = PlayerTempWindowY-TargetTempWindowY;
	local Degrees2 = (math_atan2(yDiff2,xDiff2)*(180 / math_pi)-90);	
	local degrees3 = math_cos(math_rad(Degrees2-90));
	local degrees4 = math_sin(math_rad(Degrees2-90));
	
	-- stitch line segments together
	for i=1, NumberLines do
		DynamicImageSetRotation("TetherLine"..i.."Line", Degrees2);
		WindowSetTintColor("TetherLine"..i.."Line", colorByDistance.R, colorByDistance.G, colorByDistance.B);
		local radius2 = (LineLength*i)-40;
		local xPos2 = radius2 * degrees3;
		local yPos2 = radius2 * degrees4;
		WindowClearAnchors( "TetherLine"..i );
		WindowAddAnchor( "TetherLine"..i , "center", "TetherSelfWindow", "center", xPos2,yPos2-30);
		if IsTeathered <= 0 then
			WindowSetAlpha("TetherLine"..i.."Line", newLineOpacity);
		end
	end
	
	-- hide unused line segments
	for a=(NumberLines), MaxLines do
		WindowSetAlpha("TetherLine"..a.."Line", 0);
	end
	
	-- align the last segment
	local xPosEnd = 43 * math_cos(math_rad(Degrees-270));
	local yPosEnd = 43 * math_sin(math_rad(Degrees-270));	
	DynamicImageSetRotation("TetherLineEndLine",Degrees);
	WindowSetTintColor("TetherLineEndLine", colorByDistance.R, colorByDistance.G, colorByDistance.B);
	WindowClearAnchors( "TetherLineEnd" );
	WindowAddAnchor( "TetherLineEnd", "center", "TetherTargetWindow", "center", xPosEnd, yPosEnd - 30);
	
	if IsTeathered > 0 then
		IsTeathered = IsTeathered - timeElapsed;
	else
		WindowSetAlpha("TetherLineEndLine", newLineOpacity);
	end

end

function Tether.Line.setLineTexture(textureId)
    textureId = textureId or 1;
    newTexture = TEXTURE_NAME_BY_ID[textureId];
    for i=1,MaxLines do
        DynamicImageSetTexture("TetherLine"..i.."Line", newTexture, 0, 0);
	end
    DynamicImageSetTexture("TetherLineEndLine", newTexture, 0, 0);
end

-- /script Tether.Line.test()
function Tether.Line.test()
    d(trackingMyGuard())
    d(trackingMyTanks())
    d(trackingMyTurret())
end


-- /script Tether.Line.printTarget()
function Tether.Line.printTarget()
    d(this.target);
end