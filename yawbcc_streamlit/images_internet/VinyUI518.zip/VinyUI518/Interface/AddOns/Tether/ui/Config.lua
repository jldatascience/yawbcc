Tether = Tether or {};

local towstring = towstring;

local windowName = "TetherConfigWindow";
local OFFSET_MINIMUM = 0; -- pixels
local OFFSET_MAXIMUM = 200;

local TEXTURE_LIST_NAME_BY_ID = {};
TEXTURE_LIST_NAME_BY_ID[1] = "Stock";
TEXTURE_LIST_NAME_BY_ID[2] = "Slim";
TEXTURE_LIST_NAME_BY_ID[3] = "Opaque";

function Tether.createConfigWindow()

    if (DoesWindowExist(windowName) == true) then return end

    CreateWindow(windowName, false)
	WindowSetTintColor(windowName .. "Background", 0, 0, 0);
	WindowSetAlpha(windowName .. "Background", 0.8);
    LabelSetText(windowName .. "Title", L"Tether config");
    
    ComboBoxClearMenuItems(windowName .. "LineTextureList");
	ComboBoxAddMenuItem(windowName .. "LineTextureList", L"Stock");
	ComboBoxAddMenuItem(windowName .. "LineTextureList", L"Slim");
	ComboBoxAddMenuItem(windowName .. "LineTextureList", L"Opaque");
    ComboBoxSetSelectedMenuItem(windowName .. "LineTextureList", Tether.SavedSettings.lineTextureId or 1);

    -- fill in static description labels
    LabelSetText("TetherConfigWindowGuardOutCheckboxLabel", L"track outgoing Guard");
    LabelSetText("TetherConfigWindowGuardInCheckboxLabel", L"track incoming Guard");
    LabelSetText("TetherConfigWindowTurretCheckboxLabel", L"track Magus/Engi pets");

    LabelSetText("TetherConfigWindowLineTextureTitle", L"Line texture");

	Tether.updateConfigWindow();
end

-- /script Tether.showConfig()
function Tether.showConfig()
	Tether.updateConfigWindow();
	WindowSetShowing(windowName, true);
end

-- /script Tether.hideConfigWindow();
function Tether.hideConfigWindow()
	WindowSetShowing(windowName, false);
end

-- /script Tether.updateConfigWindow()
function Tether.updateConfigWindow()

	LabelSetText(windowName .. "ObjectOffsetTitle", L"Vertical Offset");
	
	if not Tether.SavedSettings.VerticalOffset then 
		Tether.DefaultOffset();
	end

	local offset = Tether.SavedSettings.VerticalOffset;
	local sliderPosition = (offset / OFFSET_MAXIMUM);
	
	LabelSetText(windowName .. "ObjectOffsetValue", towstring(offset));
	SliderBarSetCurrentPosition(windowName .. "ObjectOffsetSlider", sliderPosition);
	
end

function Tether.OnSlideObjectOffset(sliderValue)
	-- from 0 to 1 
	--d(sliderValue);
	
	--sliderValue = tonumber(string.format("%.4f", sliderValue));
	--d(sliderValue);
	
	local newOffset = math.floor(sliderValue/0.005);
	--d(newOffset);

	LabelSetText(windowName .. "ObjectOffsetValue", towstring(newOffset));
	Tether.SetOffset(newOffset);
	
end

function Tether.onLineTextureChanged(newTextureId)
    Tether.SavedSettings.lineTextureId = newTextureId or 1;
    Tether.Line.setLineTexture(Tether.SavedSettings.lineTextureId)
end


function Tether.setUpCheckboxes()
    
    if not Tether.playingTank or Tether.playingTank == false then
        ButtonSetPressedFlag( windowName .. "GuardOutCheckbox", Tether.SavedSettings.guardOutTracker);
        ButtonSetDisabledFlag( "TetherConfigWindowGuardOutCheckbox", true);
    else
        ButtonSetPressedFlag( "TetherConfigWindowGuardOutCheckbox", Tether.SavedSettings.guardOutTracker);
        ButtonSetDisabledFlag( "TetherConfigWindowGuardOutCheckbox", false);
        ButtonSetDisabledFlag( "TetherConfigWindowGuardInCheckbox", true);
    end

    ButtonSetPressedFlag( "TetherConfigWindowGuardInCheckbox", Tether.SavedSettings.guardInTracker);

    if not Tether.playingTurretClass or Tether.playingTurretClass == false then
        ButtonSetDisabledFlag( "TetherConfigWindowTurretCheckbox", true);
    else
        ButtonSetPressedFlag( "TetherConfigWindowTurretCheckbox", Tether.SavedSettings.turretTracker);
    end

end


function Tether.toggleGuardOutTracker()
    local isDisabled = ButtonGetDisabledFlag(windowName .. "GuardOutCheckbox");
    if isDisabled == true then return end
    Tether.SavedSettings.guardOutTracker = not Tether.SavedSettings.guardOutTracker;
    ButtonSetPressedFlag(windowName .. "GuardOutCheckbox", Tether.SavedSettings.guardOutTracker);
    if Tether.SavedSettings.guardOutTracker == true then
        Tether.GuardOut.initialize();
    else
        Tether.GuardOut.shutDown();
    end    
end

function Tether.toggleGuardInTracker(arg)
	local isDisabled = ButtonGetDisabledFlag(windowName .. "GuardInCheckbox");
    if isDisabled == true then return end
    Tether.SavedSettings.guardInTracker = not Tether.SavedSettings.guardInTracker;
    ButtonSetPressedFlag(windowName .. "GuardInCheckbox", Tether.SavedSettings.guardInTracker);
    if Tether.SavedSettings.guardInTracker == true then
        Tether.GuardIn.initialize();
    else
        Tether.GuardIn.shutDown();
    end
end

function Tether.toggleTurretTracker()
	local isDisabled = ButtonGetDisabledFlag(windowName .. "TurretCheckbox");
    if isDisabled == true then return end
    Tether.SavedSettings.turretTracker = not Tether.SavedSettings.turretTracker;
    ButtonSetPressedFlag(windowName .. "TurretCheckbox", Tether.SavedSettings.turretTracker);
    if Tether.SavedSettings.turretTracker == true then
        Tether.TurretTracker.initialize();
    else
        Tether.TurretTracker.shutDown();
    end
end



