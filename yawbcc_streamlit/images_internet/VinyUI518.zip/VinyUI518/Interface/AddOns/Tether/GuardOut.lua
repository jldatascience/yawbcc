-- based on GeS by Medikage
-- https://tools.idrinth.de/addons/ges/

Tether = Tether or {};
Tether.GuardOut = Tether.GuardOut or {};

-- locals for performance
local pairs = pairs;
local GetBuffs = GetBuffs;
local fixName = Tether.Utils.fixName;
local isTableEmpty = Tether.Utils.isTableEmpty;

local Print = Tether.Utils.Print;

-- syntax sugar
local this = Tether.GuardOut;

-- constants
local GUARD_EFFECTS = Tether.Utils.GUARD_EFFECTS;

-- runtime
this.enabled = false;
this.target = {objectId = nil, name = nil};
this.tempTarget = {objectId = nil, name = nil};

local myGuardIsApplied = false;
local guardEffectIndex = nil;
local startedCastingGuard = false;


local function getGuardEffectIndex(myEffects)
    if not myEffects then return nil end
    for effectIndex, effect in pairs (myEffects) do
        if GUARD_EFFECTS[effect.abilityId] and effect.castByPlayer == true then
			return effectIndex;
		end
	end
	return nil;
end

function Tether.GuardOut.initialize()
    if (not this.enabled or this.enabled == false) then
        RegisterEventHandler( SystemData.Events.PLAYER_BEGIN_CAST, "Tether.GuardOut.onBeginCast" );
        RegisterEventHandler( SystemData.Events.PLAYER_END_CAST, "Tether.GuardOut.onEndCast" );
        RegisterEventHandler( SystemData.Events.PLAYER_EFFECTS_UPDATED, "Tether.GuardOut.onPlayerEffectsUpdated" );
        this.enabled = true;
        --d("[Tether] GuardOut tracker has been initialized.");
    end    
end

function Tether.GuardOut.shutDown()
    if (this.enabled == true) then
        UnregisterEventHandler( SystemData.Events.PLAYER_BEGIN_CAST, "Tether.GuardOut.onBeginCast");
        UnregisterEventHandler( SystemData.Events.PLAYER_END_CAST, "Tether.GuardOut.onEndCast");
        UnregisterEventHandler( SystemData.Events.PLAYER_EFFECTS_UPDATED, "Tether.GuardOut.onPlayerEffectsUpdated");
        this.enabled = false;
        --d("[Tether] GuardOut tracker has been disabled.");
    end
end


function Tether.GuardOut.onBeginCast(spellId, channel, castTime, averageLatency)
    if not GUARD_EFFECTS[spellId] then return end
    startedCastingGuard = true;
    TargetInfo:UpdateFromClient();
    this.tempTarget.objectId = TargetInfo:UnitEntityId("selffriendlytarget");
    this.tempTarget.name = fixName(TargetInfo:UnitName("selffriendlytarget"));
end

function Tether.GuardOut.onEndCast(castFailed)

    if startedCastingGuard == false then return end

    startedCastingGuard = false;
    if castFailed == true then return end

    -- check if there is a guard effect on me
    local selfBuffData = GetBuffs(GameData.BuffTargetType.SELF);
    guardEffectIndex = getGuardEffectIndex(selfBuffData);
    if guardEffectIndex then
        -- create a brand new target object using temp target primitives
        this.target = {
            objectId = this.tempTarget.objectId,
            name = this.tempTarget.name
        };
        this.tempTarget = {};
        Tether.Line.attatchToTarget(this.target);
        myGuardIsApplied = true;
    end

end


function Tether.GuardOut.onPlayerEffectsUpdated(updatedBuffsTable, isFullList)
    -- we are only interested in verifying that our guard has been removed
    if not guardEffectIndex or myGuardIsApplied ~= true or not updatedBuffsTable then return end
    for effectIndex, effect in pairs (updatedBuffsTable) do
        if (effectIndex == guardEffectIndex) and (not effect.name) then
            guardEffectIndex = nil;
            myGuardIsApplied = false;
            Tether.Line.clearTarget();
        end
    end
end