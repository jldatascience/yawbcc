-- based on TurretRange by Healix
-- https://tools.idrinth.de/addons/turret-range/

Tether = Tether or {};
Tether.Location = Tether.Location or {};
Tether.TurretTracker = Tether.TurretTracker or {};

-- locals for performance
local math_floor = math.floor
local math_sqrt = math.sqrt
local math_pow = math.pow

local Print = Tether.Utils.Print;

-- syntax sugar
local this = Tether.TurretTracker;
local location = Tether.Location;

-- constants
local DISTANCE_UPDATE_DELAY = 0.1;
local LOCATION_TO_DISTANCE = 0.084; -- modifier for changing [x, y] points to distance (calculated based on Mythic's distances)
local TURRET_REPOSITION_SPELLS = { -- recalled turrets appear exactly on player position
    [1532] = true,
    [8542] = true
};

local TURRET_SUMMON_SPELLS = { -- summoned turrets appear ~5 ft in front of the player
    [1511]=true, -- gun turret
    [1518]=true, -- bombardment turret
    [1526]=true, -- flame turret
    [8474]=true, -- Summon Pink Horror
    [8476]=true, -- Summon Blue Horror
    [8478]=true -- Summon Flamer
};

local SPECIAL_TURRETS = { -- turrets with a tall hitbox
    [8478]=true -- Summon Flamer
};

local TURRET_ICON_BY_SPELL = {
    [1511]="icon004602", -- gun turret
    [1518]="icon004607", -- bombardment turret
    [1526]="icon004613", -- flame turret
    [8474]="icon005272", -- Summon Pink Horror
    [8476]="icon005276", -- Summon Blue Horror
    [8478]="icon005280" -- Summon Flamer
};

local TURRET_CHAT_ICON_BY_SPELL = {
    [1511]=L"<icon04602>", -- gun turret
    [1518]=L"<icon04607>", -- bombardment turret
    [1526]=L"<icon04613>", -- flame turret
    [8474]=L"<icon05272>", -- Summon Pink Horror
    [8476]=L"<icon05276>", -- Summon Blue Horror
    [8478]=L"<icon05280>" -- Summon Flamer
};

local GAIN_RADIUS = 24;     -- distance in ft at which number of damage stacks is increaed (up to 8 stacks)
local MAINTAN_RADIUS = 80;  -- distance in ft at which number of damage stacks is maintained (but not gained or lost)

local COLOR_DEFAULT = {R=160,G=160,B=160};
local COLOR_GAIN = {R=50,G=255,B=50};
local COLOR_MAINTAIN = {R=100,G=100,B=255};
local COLOR_LOSE = {R=255,G=50,B=50};

-- runtime
this.enabled = false;
this.target = {}
this.turretTexture = nil;
this.turretChatIcon = L"<icon00080>";
this.isSpecialTurret = false;
this.turretIsDeployed = false;
this.distanceToTurret = nil;
this.distanceColor = COLOR_DEFAULT;

local deploymentStarted = false;
local turretSpellId = nil;
local placedBySummon;

local function synchTurretLocation()
	Tether.Location.Turret = Tether.Location.Player;
end

local function getDistanceToTurret()
    if not location or not location.Player or not location.Turret then return nil end
	local playerX, playerY = location.Player.X, location.Player.Y;
	local turretX, turretY = location.Turret.X, location.Turret.Y;
	local dX, dY = playerX - turretX, playerY - turretY;
    return math_floor((math_sqrt(math_pow(dX, 2) + math_pow(dY, 2))) * LOCATION_TO_DISTANCE);
end

local function getColorByDistance(distance)
    if not distance then return COLOR_DEFAULT end
    -- flame turrets have different rules
    if turretSpellId == 8478 or turretSpellId == 1518 then
        if distance >= 0 and distance <= GAIN_RADIUS then
            return COLOR_GAIN;
        elseif distance > GAIN_RADIUS and distance < MAINTAN_RADIUS then
            return COLOR_MAINTAIN;
        else
            return COLOR_LOSE;
        end
    else
        if distance >= 0 and distance <= GAIN_RADIUS then
            return COLOR_GAIN;
        else
            return COLOR_LOSE;
        end
    end
end

function Tether.TurretTracker.initialize()
    if not this.enabled or this.enabled == false then
        RegisterEventHandler(SystemData.Events.PLAYER_PET_UPDATED, "Tether.TurretTracker.onPetUpdated");
        RegisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "Tether.TurretTracker.onPlayerPositionUpdated");
        RegisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "Tether.TurretTracker.onBeginCast");
        RegisterEventHandler(SystemData.Events.PLAYER_END_CAST, "Tether.TurretTracker.onEndCast");
        --d("[Tether] TurretTracker tracker has been initialized.");
        this.enabled = true;
    end
end

function Tether.TurretTracker.shutDown()
    if (this.enabled == true) then
        this.clearLineToPet();
        this.turretIsDeployed = false;
        this.distanceToTurret = nil;
        UnregisterEventHandler(SystemData.Events.PLAYER_PET_UPDATED, "Tether.TurretTracker.onPetUpdated");
        UnregisterEventHandler(SystemData.Events.PLAYER_POSITION_UPDATED, "Tether.TurretTracker.onPlayerPositionUpdated");
        UnregisterEventHandler(SystemData.Events.PLAYER_BEGIN_CAST, "Tether.TurretTracker.onBeginCast");
        UnregisterEventHandler(SystemData.Events.PLAYER_END_CAST, "Tether.TurretTracker.onEndCast");
        --d("[Tether] TurretTracker tracker has been disabled.");
        this.enabled = false;
    end
end


function Tether.TurretTracker.onBeginCast(spellId, channel, castTime)
    if TURRET_REPOSITION_SPELLS[spellId] then
        synchTurretLocation();
        placedBySummon = false;
    elseif TURRET_SUMMON_SPELLS[spellId] then
        --d("Tether.TurretTracker.onBeginCast(spellId, channel, castTime)")
		turretSpellId = spellId
		deploymentStarted = true;
    else
        placedBySummon = false;
		deploymentStarted = false;
	end
end

function Tether.TurretTracker.onEndCast(castFailed)
    if deploymentStarted ~= true or castFailed == true then return end
    --d("Tether.TurretTracker.onEndCast()")
    synchTurretLocation();
    placedBySummon = true;
    this.isSpecialTurret = SPECIAL_TURRETS[turretSpellId] or false;
    deploymentStarted = false;
end

function Tether.TurretTracker.onPetUpdated()
    --d("Tether.TurretTracker.onPetUpdated()")
    local pet = GameData.Player.Pet;

    -- pet has been removed
    if pet.name == nil or pet.name == L"" then 
        this.turretIsDeployed = false;
        this.clearLineToPet();
    -- pet has been summoned
    else
        synchTurretLocation();
        this.turretIsDeployed = true;
        this.turretTexture = TURRET_ICON_BY_SPELL[turretSpellId];
        this.turretChatIcon = TURRET_CHAT_ICON_BY_SPELL[turretSpellId];
        this.target = {objectId = pet.objNum, name = pet.name, isTurret = true, isSpecialTurret = this.isSpecialTurret};
        if Tether.iAmGuarded() == false then
            Tether.Line.attatchToTarget(this.target);
        else
            WindowSetShowing( "TetherTurretInfo", true);
        end
    end

end


function Tether.TurretTracker.onPlayerPositionUpdated(newX, newY)
	Tether.Location.Player = { X = newX, Y = newY };
end

local timeLeft = DISTANCE_UPDATE_DELAY;
function Tether.TurretTracker.onUpdate(elapsed)
    if not this.turretIsDeployed or this.turretIsDeployed ~= true then return end
	timeLeft = timeLeft - elapsed;
    if (timeLeft > 0) then return end
    this.distanceToTurret = getDistanceToTurret();
    this.distanceColor = getColorByDistance(this.distanceToTurret) or COLOR_DEFAULT;
	timeLeft = DISTANCE_UPDATE_DELAY;
end


function Tether.TurretTracker.clearLineToPet()
    if Tether.iAmGuarded() == false then
        Tether.Line.clearTarget();
    end
    WindowSetShowing( "TetherTurretInfo", false);
end